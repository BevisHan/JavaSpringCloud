﻿using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc.Formatters;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.EntityFrameworkCore;
using Augmentum.PatronManagement.Core.Models;
using Augmentum.PatronManagement.Core.Repositories;
using EntityFramework.DbContextScope.Interfaces;
using Augmentum.PatronManagement.Core.Db;
using EntityFramework.DbContextScope;
using Augmentum.PatronManagement.Core.Services;

namespace Augmentum.PatronManagement.Core
{
    public class Startup
    {
        private readonly ILogger<Startup> _logger;

        public Startup(IConfiguration configuration, ILogger<Startup> logger, IHostingEnvironment env)
        {
            Configuration = configuration;
            _logger = logger;

            var builder = new ConfigurationBuilder()
            .SetBasePath(env.ContentRootPath)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
            .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; }


        // Tis method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationInsightsTelemetry();
            services.AddOptions();

            services.AddMvc(options =>
            {
                options.OutputFormatters.RemoveType(typeof(HttpNoContentOutputFormatter));
                options.OutputFormatters.Insert(0, new HttpNoContentOutputFormatter
                {
                    TreatNullValueAsNoContent = false
                });
            }).AddJsonOptions(options =>
            {
                options.SerializerSettings.Formatting = Formatting.Indented;
            });

            InjectSwagger(services);
            InjectDbContextScope(services);
            InjectServices(services);
            InjectRepositories(services);

            services.AddDbContext<PMDbContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("PMDB"), option => option.CommandTimeout(30));
            });
        }

        private void InjectSwagger(IServiceCollection services)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info { Title = "Patron Information Provider for VELO CMS", Version = "v1" });

                options.IncludeXmlComments(Path.Combine(System.AppContext.BaseDirectory, "PatronManagement.Core.xml"));
            });

        }

        private void InjectRepositories(IServiceCollection services)
        {
            services.AddTransient<IPmPatronInfoRepository, PmPatronInfoRepository>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Patron Information Provider V1");
                c.RoutePrefix = "swagger";
            });

            app.UseSwagger();

            app.UseStaticFiles();

            app.UseMvc();
        }

        private void InjectDbContextScope(IServiceCollection services)
        {
            services.AddSingleton<IDbContextFactory, PMDbContextFactory>();
            services.AddSingleton<IDbContextScopeFactory, DbContextScopeFactory>();
            services.AddSingleton<IAmbientDbContextLocator, AmbientDbContextLocator>();

            services.AddScoped<IReadDbFacade, ReadDbFacade>();
        }

        private void InjectServices(IServiceCollection services)
        {
            services.AddTransient<IPatronService, PatronService>();
        }
    }
}
