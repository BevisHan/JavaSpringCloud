﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PMDbContext : DbContext
    {
        public PMDbContext()
        {
        }

        public PMDbContext(DbContextOptions<PMDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CompanyDn> CompanyDn { get; set; }
        public virtual DbSet<MarkerCustomerMarkerInfo> MarkerCustomerMarkerInfo { get; set; }
        public virtual DbSet<MarkerCustomerMarkerInfoExtension> MarkerCustomerMarkerInfoExtension { get; set; }
        public virtual DbSet<PmAccount> PmAccount { get; set; }
        public virtual DbSet<PmAccountExtension> PmAccountExtension { get; set; }
        public virtual DbSet<PmAddressLine> PmAddressLine { get; set; }
        public virtual DbSet<PmClub> PmClub { get; set; }
        public virtual DbSet<PmGeographic> PmGeographic { get; set; }
        public virtual DbSet<PmGroups> PmGroups { get; set; }
        public virtual DbSet<PmIdent> PmIdent { get; set; }
        public virtual DbSet<PmImage> PmImage { get; set; }
        public virtual DbSet<PmJackpot> PmJackpot { get; set; }
        public virtual DbSet<PmJunket> PmJunket { get; set; }
        public virtual DbSet<PmJunketRep> PmJunketRep { get; set; }
        public virtual DbSet<PmLanguages> PmLanguages { get; set; }
        public virtual DbSet<PmLink> PmLink { get; set; }
        public virtual DbSet<PmMarketingHost> PmMarketingHost { get; set; }
        public virtual DbSet<PmPatronAccount> PmPatronAccount { get; set; }
        public virtual DbSet<PmPatronAccountExtension> PmPatronAccountExtension { get; set; }
        public virtual DbSet<PmPatronActivity> PmPatronActivity { get; set; }
        public virtual DbSet<PmPatronAddress> PmPatronAddress { get; set; }
        public virtual DbSet<PmPatronCard> PmPatronCard { get; set; }
        public virtual DbSet<PmPatronClub> PmPatronClub { get; set; }
        public virtual DbSet<PmPatronComment> PmPatronComment { get; set; }
        public virtual DbSet<PmPatronCustom> PmPatronCustom { get; set; }
        public virtual DbSet<PmPatronEmail> PmPatronEmail { get; set; }
        public virtual DbSet<PmPatronGroup> PmPatronGroup { get; set; }
        public virtual DbSet<PmPatronIdent> PmPatronIdent { get; set; }
        public virtual DbSet<PmPatronImage> PmPatronImage { get; set; }
        public virtual DbSet<PmPatronInfo> PmPatronInfo { get; set; }
        public virtual DbSet<PmPatronInfoPatronClub> PmPatronInfoPatronClub { get; set; }
        public virtual DbSet<PmPatronInfoPatronCustom> PmPatronInfoPatronCustom { get; set; }
        public virtual DbSet<PmPatronInfoPatronGroup> PmPatronInfoPatronGroup { get; set; }
        public virtual DbSet<PmPatronInfoPatronLink> PmPatronInfoPatronLink { get; set; }
        public virtual DbSet<PmPatronInfoPatronStop> PmPatronInfoPatronStop { get; set; }
        public virtual DbSet<PmPatronInfoPatronTag> PmPatronInfoPatronTag { get; set; }
        public virtual DbSet<PmPatronLastActivity> PmPatronLastActivity { get; set; }
        public virtual DbSet<PmPatronLink> PmPatronLink { get; set; }
        public virtual DbSet<PmPatronName> PmPatronName { get; set; }
        public virtual DbSet<PmPatronPhone> PmPatronPhone { get; set; }
        public virtual DbSet<PmPatronPointAccountTransaction> PmPatronPointAccountTransaction { get; set; }
        public virtual DbSet<PmPatronPreference> PmPatronPreference { get; set; }
        public virtual DbSet<PmPatronPreferenceType> PmPatronPreferenceType { get; set; }
        public virtual DbSet<PmPatronProfile> PmPatronProfile { get; set; }
        public virtual DbSet<PmPatronProfileExtension> PmPatronProfileExtension { get; set; }
        public virtual DbSet<PmPatronRelation> PmPatronRelation { get; set; }
        public virtual DbSet<PmPatronSign> PmPatronSign { get; set; }
        public virtual DbSet<PmPatronSignitureImage> PmPatronSignitureImage { get; set; }
        public virtual DbSet<PmPatronStop> PmPatronStop { get; set; }
        public virtual DbSet<PmPatronTag> PmPatronTag { get; set; }
        public virtual DbSet<PmProfileAttribute> PmProfileAttribute { get; set; }
        public virtual DbSet<PmPromotion> PmPromotion { get; set; }
        public virtual DbSet<PmReInvestmentExpense> PmReInvestmentExpense { get; set; }
        public virtual DbSet<PmRelation> PmRelation { get; set; }
        public virtual DbSet<PmStandardRatingInformation> PmStandardRatingInformation { get; set; }
        public virtual DbSet<PmStandardRatings2sLog> PmStandardRatings2sLog { get; set; }
        public virtual DbSet<PmStop> PmStop { get; set; }
        public virtual DbSet<PmTrip> PmTrip { get; set; }
        public virtual DbSet<PmTripAction> PmTripAction { get; set; }
        public virtual DbSet<PmUsages> PmUsages { get; set; }
        public virtual DbSet<RatingCustomerRatingSummary> RatingCustomerRatingSummary { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<CompanyDn>(entity =>
            {
                entity.ToTable("company_dn");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Company)
                    .HasColumnName("company")
                    .HasMaxLength(255);

                entity.Property(e => e.CompanyName)
                    .HasColumnName("company_name")
                    .HasMaxLength(255);

                entity.Property(e => e.DomainName)
                    .HasColumnName("domain_name")
                    .HasMaxLength(255);

                entity.Property(e => e.Property)
                    .HasColumnName("property")
                    .HasMaxLength(255);

                entity.Property(e => e.PropertyName)
                    .HasColumnName("property_name")
                    .HasMaxLength(255);

                entity.Property(e => e.TenantId).HasColumnName("tenant_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<MarkerCustomerMarkerInfo>(entity =>
            {
                entity.ToTable("marker_CustomerMarkerInfo");

                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Currency).HasMaxLength(36);

                entity.Property(e => e.CustomerId).HasMaxLength(36);

                entity.Property(e => e.IssueDate).HasColumnType("datetime");

                entity.Property(e => e.MarkerDocumentId).HasMaxLength(36);

                entity.Property(e => e.MarkerId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.Property(e => e.Status).HasMaxLength(36);

                entity.Property(e => e.TenantId).HasColumnName("tenantId");
            });

            modelBuilder.Entity<MarkerCustomerMarkerInfoExtension>(entity =>
            {
                entity.ToTable("marker_CustomerMarkerInfoExtension");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.AttributeName)
                    .HasColumnName("attributeName")
                    .HasMaxLength(50);

                entity.Property(e => e.MarkerCustomerMarkerInfoId)
                    .IsRequired()
                    .HasColumnName("marker_CustomerMarkerInfo_id")
                    .HasMaxLength(36);

                entity.Property(e => e.Value)
                    .HasColumnName("value")
                    .HasMaxLength(200);
            });

            modelBuilder.Entity<PmAccount>(entity =>
            {
                entity.HasKey(e => e.AccountId)
                    .HasName("PK__pm_accou__46A222CDB0784723");

                entity.ToTable("pm_account");

                entity.Property(e => e.AccountId)
                    .HasColumnName("account_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AccountActive).HasColumnName("account_active");

                entity.Property(e => e.AccountName)
                    .IsRequired()
                    .HasColumnName("account_name")
                    .HasMaxLength(32);

                entity.Property(e => e.AccountType)
                    .HasColumnName("account_type")
                    .HasMaxLength(64);

                entity.Property(e => e.ForeignId).HasColumnName("foreign_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmAccountExtension>(entity =>
            {
                entity.HasKey(e => e.AccountId)
                    .HasName("PK__pm_accou__46A222CD551158C5");

                entity.ToTable("pm_account_extension");

                entity.Property(e => e.AccountId)
                    .HasColumnName("account_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AccountActive).HasColumnName("account_active");

                entity.Property(e => e.AccountAvailability).HasColumnName("account_availability");

                entity.Property(e => e.AccountBalance).HasColumnName("account_balance");

                entity.Property(e => e.AccountName)
                    .IsRequired()
                    .HasColumnName("account_name")
                    .HasMaxLength(32);

                entity.Property(e => e.AccountType)
                    .HasColumnName("account_type")
                    .HasMaxLength(64);

                entity.Property(e => e.ForeignId).HasColumnName("foreign_id");

                entity.Property(e => e.PatronAccountExtension)
                    .HasColumnName("patron_account_extension")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmAddressLine>(entity =>
            {
                entity.HasKey(e => e.Line)
                    .HasName("PK__pm_addre__A269238A2174AD25");

                entity.ToTable("pm_address_line");

                entity.Property(e => e.Line)
                    .HasColumnName("line")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AddressLineValue)
                    .IsRequired()
                    .HasColumnName("address_line_value")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronAddress)
                    .HasColumnName("patron_address")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmClub>(entity =>
            {
                entity.HasKey(e => e.ClubId)
                    .HasName("PK__pm_club__BCAD3DD913B3A679");

                entity.ToTable("pm_club");

                entity.Property(e => e.ClubId)
                    .HasColumnName("club_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ClubActive).HasColumnName("club_active");

                entity.Property(e => e.ClubName)
                    .IsRequired()
                    .HasColumnName("club_name")
                    .HasMaxLength(32);

                entity.Property(e => e.ClubNotify).HasColumnName("club_notify");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmGeographic>(entity =>
            {
                entity.ToTable("pm_geographic");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.GeographicActive).HasColumnName("geographic_active");

                entity.Property(e => e.GeographicId)
                    .IsRequired()
                    .HasColumnName("geographic_id")
                    .HasMaxLength(32);

                entity.Property(e => e.GeographicName)
                    .HasColumnName("geographic_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmGroups>(entity =>
            {
                entity.HasKey(e => e.GroupId)
                    .HasName("PK__pm_group__D57795A07ED8133C");

                entity.ToTable("pm_groups");

                entity.Property(e => e.GroupId)
                    .HasColumnName("group_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.GroupActive).HasColumnName("group_active");

                entity.Property(e => e.GroupEffDate)
                    .HasColumnName("group_eff_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.GroupExpDate)
                    .HasColumnName("group_exp_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasColumnName("group_name")
                    .HasMaxLength(32);

                entity.Property(e => e.GroupNotify).HasColumnName("group_notify");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmIdent>(entity =>
            {
                entity.HasKey(e => e.IdentId)
                    .HasName("PK__pm_ident__06DA0DF17162AEDE");

                entity.ToTable("pm_ident");

                entity.Property(e => e.IdentId)
                    .HasColumnName("ident_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IdentActive).HasColumnName("ident_active");

                entity.Property(e => e.IdentName)
                    .IsRequired()
                    .HasColumnName("ident_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmImage>(entity =>
            {
                entity.HasKey(e => e.ImageId)
                    .HasName("PK__pm_image__DC9AC955D1C3CB41");

                entity.ToTable("pm_image");

                entity.Property(e => e.ImageId)
                    .HasColumnName("image_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ImageActive).HasColumnName("image_active");

                entity.Property(e => e.ImageName)
                    .IsRequired()
                    .HasColumnName("image_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmJackpot>(entity =>
            {
                entity.ToTable("pm_jackpot");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.Blackout).HasColumnName("blackout");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasColumnName("code")
                    .HasMaxLength(255);

                entity.Property(e => e.CurrentValue)
                    .HasColumnName("current_value")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.DisplayJackpot).HasColumnName("display_jackpot");

                entity.Property(e => e.LastUpdated)
                    .HasColumnName("last_updated")
                    .HasColumnType("datetime");

                entity.Property(e => e.NextdrawPeriod)
                    .HasColumnName("nextdraw_period")
                    .HasColumnType("datetime");

                entity.Property(e => e.PatronId)
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmJunket>(entity =>
            {
                entity.HasKey(e => e.JunketId)
                    .HasName("PK__pm_junke__B2EB5D70B5AD9AA0");

                entity.ToTable("pm_junket");

                entity.Property(e => e.JunketId)
                    .HasColumnName("junket_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.JunketActive).HasColumnName("junket_active");

                entity.Property(e => e.JunketEndDate)
                    .HasColumnName("junket_end_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.JunketName)
                    .IsRequired()
                    .HasColumnName("junket_name")
                    .HasMaxLength(32);

                entity.Property(e => e.JunketNotify).HasColumnName("junket_notify");

                entity.Property(e => e.JunketRepId)
                    .HasColumnName("junket_rep_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.JunketStrDate)
                    .HasColumnName("junket_str_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmJunketRep>(entity =>
            {
                entity.HasKey(e => e.JunketRepId)
                    .HasName("PK__pm_junke__3F3E9CFDF87D5B09");

                entity.ToTable("pm_junket_rep");

                entity.Property(e => e.JunketRepId)
                    .HasColumnName("junket_rep_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.JunketRepActive).HasColumnName("junket_rep_active");

                entity.Property(e => e.JunketRepName)
                    .IsRequired()
                    .HasColumnName("junket_rep_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmLanguages>(entity =>
            {
                entity.HasKey(e => e.LanguageId)
                    .HasName("PK__pm_langu__804CF6B3DF929273");

                entity.ToTable("pm_languages");

                entity.Property(e => e.LanguageId)
                    .HasColumnName("language_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasColumnType("text");

                entity.Property(e => e.LanguageActive).HasColumnName("language_active");

                entity.Property(e => e.LanguageName)
                    .HasColumnName("language_name")
                    .HasMaxLength(50);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmLink>(entity =>
            {
                entity.HasKey(e => e.LinkId)
                    .HasName("PK__pm_link__93B0078C9093FB9D");

                entity.ToTable("pm_link");

                entity.Property(e => e.LinkId)
                    .HasColumnName("link_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.LinkActive).HasColumnName("link_active");

                entity.Property(e => e.LinkName)
                    .IsRequired()
                    .HasColumnName("link_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmMarketingHost>(entity =>
            {
                entity.ToTable("pm_marketing_host");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.MarketerName)
                    .HasColumnName("marketer_name")
                    .HasMaxLength(100);

                entity.Property(e => e.PhoneNumber)
                    .HasColumnName("phone_number")
                    .HasMaxLength(20);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronAccount>(entity =>
            {
                entity.ToTable("pm_patron_account");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AccountAvailability).HasColumnName("account_availability");

                entity.Property(e => e.AccountBalance)
                    .HasColumnName("account_balance")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.AccountId)
                    .HasColumnName("account_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.AccountType)
                    .HasColumnName("account_type")
                    .HasMaxLength(255);

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CompItemId).HasColumnName("comp_item_id");

                entity.Property(e => e.CompLocId).HasColumnName("comp_loc_id");

                entity.Property(e => e.ForeignAvailability).HasColumnName("foreign_availability");

                entity.Property(e => e.ForeignBalance).HasColumnName("foreign_balance");

                entity.Property(e => e.ForeignExpiry)
                    .HasColumnName("foreign_expiry")
                    .HasColumnType("datetime");

                entity.Property(e => e.ForeignId).HasColumnName("foreign_id");

                entity.Property(e => e.ForeignRate).HasColumnName("foreign_rate");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.UpdateTime)
                    .HasColumnName("update_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronAccountExtension>(entity =>
            {
                entity.ToTable("pm_patron_account_extension");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AccountAvailability).HasColumnName("account_availability");

                entity.Property(e => e.AccountBalance).HasColumnName("account_balance");

                entity.Property(e => e.AccountType)
                    .HasColumnName("account_type")
                    .HasMaxLength(255);

                entity.Property(e => e.CompItemId).HasColumnName("comp_item_id");

                entity.Property(e => e.CompLocId).HasColumnName("comp_loc_id");

                entity.Property(e => e.ForeignAvailability).HasColumnName("foreign_availability");

                entity.Property(e => e.ForeignBalance).HasColumnName("foreign_balance");

                entity.Property(e => e.ForeignExpiry)
                    .HasColumnName("foreign_expiry")
                    .HasColumnType("datetime");

                entity.Property(e => e.ForeignId).HasColumnName("foreign_id");

                entity.Property(e => e.ForeignRate).HasColumnName("foreign_rate");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.UpdateTime)
                    .HasColumnName("update_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronActivity>(entity =>
            {
                entity.HasKey(e => e.PatronActivityId)
                    .HasName("PK__pm_patro__D47A1262B18D2065");

                entity.ToTable("pm_patron_activity");

                entity.Property(e => e.PatronActivityId)
                    .HasColumnName("patron_activity_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Activity)
                    .HasColumnName("activity")
                    .HasMaxLength(255);

                entity.Property(e => e.ActivityShortDesc)
                    .HasColumnName("activity_short_desc")
                    .HasMaxLength(255);

                entity.Property(e => e.ActivityTime)
                    .HasColumnName("activity_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.ActivityType)
                    .HasColumnName("activity_type")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronTripId)
                    .HasColumnName("patron_trip_id")
                    .HasMaxLength(36);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronAddress>(entity =>
            {
                entity.HasKey(e => e.PatronAddressId)
                    .HasName("PK__pm_patro__C438E4B3F4866568");

                entity.ToTable("pm_patron_address");

                entity.Property(e => e.PatronAddressId)
                    .HasColumnName("patron_address_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AddressActive).HasColumnName("address_active");

                entity.Property(e => e.AddressCareOf)
                    .HasColumnName("address_care_of")
                    .HasMaxLength(255);

                entity.Property(e => e.AddressCity)
                    .HasColumnName("address_city")
                    .HasMaxLength(255);

                entity.Property(e => e.AddressComment)
                    .HasColumnName("address_comment")
                    .HasMaxLength(255);

                entity.Property(e => e.AddressExclude).HasColumnName("address_exclude");

                entity.Property(e => e.AddressLineValue)
                    .HasColumnName("address_line_value")
                    .HasMaxLength(255);

                entity.Property(e => e.AddressMailCode)
                    .HasColumnName("address_mail_code")
                    .HasMaxLength(255);

                entity.Property(e => e.AddressMailTo).HasColumnName("address_mail_to");

                entity.Property(e => e.AddressPlain).HasColumnName("address_plain");

                entity.Property(e => e.AddressPrimary).HasColumnName("address_primary");

                entity.Property(e => e.AddressRtnMail).HasColumnName("address_rtn_mail");

                entity.Property(e => e.AddressSuburb)
                    .HasColumnName("address_suburb")
                    .HasMaxLength(255);

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CountryId)
                    .HasColumnName("country_id")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PostCodeExt)
                    .HasColumnName("post_code_ext")
                    .HasMaxLength(255);

                entity.Property(e => e.PostCodeId)
                    .HasColumnName("post_code_id")
                    .HasMaxLength(255);

                entity.Property(e => e.StateProvId)
                    .HasColumnName("state_prov_id")
                    .HasMaxLength(255);

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronCard>(entity =>
            {
                entity.ToTable("pm_patron_card");

                entity.HasIndex(e => e.CardId)
                    .HasName("UK_nqr6oycmv4n8nb7sjad4uu66c")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CardActive).HasColumnName("card_active");

                entity.Property(e => e.CardExp)
                    .HasColumnName("card_exp")
                    .HasColumnType("datetime");

                entity.Property(e => e.CardId)
                    .IsRequired()
                    .HasColumnName("card_id")
                    .HasMaxLength(255);

                entity.Property(e => e.CardLost).HasColumnName("card_lost");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronClub>(entity =>
            {
                entity.ToTable("pm_patron_club");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.ClubActive).HasColumnName("club_active");

                entity.Property(e => e.ClubEffDate)
                    .HasColumnName("club_eff_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClubExpDate)
                    .HasColumnName("club_exp_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClubId).HasColumnName("club_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronComment>(entity =>
            {
                entity.HasKey(e => e.PatronCommentId)
                    .HasName("PK__pm_patro__E51A7876C6FC2D7E");

                entity.ToTable("pm_patron_comment");

                entity.Property(e => e.PatronCommentId)
                    .HasColumnName("patron_comment_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CommentActive).HasColumnName("comment_active");

                entity.Property(e => e.CommentBy)
                    .HasColumnName("comment_by")
                    .HasMaxLength(255);

                entity.Property(e => e.CommentDateTime)
                    .HasColumnName("comment_date_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.CommentExp)
                    .HasColumnName("comment_exp")
                    .HasColumnType("datetime");

                entity.Property(e => e.CommentMandatory).HasColumnName("comment_mandatory");

                entity.Property(e => e.CommentPriority).HasColumnName("comment_priority");

                entity.Property(e => e.CommentSource)
                    .HasColumnName("comment_source")
                    .HasMaxLength(255);

                entity.Property(e => e.CommentText)
                    .IsRequired()
                    .HasColumnName("comment_text")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronCustom>(entity =>
            {
                entity.ToTable("pm_patron_custom");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronCustomId).HasColumnName("patron_custom_id");

                entity.Property(e => e.PatronCustomInactive).HasColumnName("patron_custom_inactive");

                entity.Property(e => e.PatronCustomValue)
                    .IsRequired()
                    .HasColumnName("patron_custom_value")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronEmail>(entity =>
            {
                entity.HasKey(e => e.PatronEmailId)
                    .HasName("PK__pm_patro__F41BFFE7C9640274");

                entity.ToTable("pm_patron_email");

                entity.Property(e => e.PatronEmailId)
                    .HasColumnName("patron_email_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.EmailActive).HasColumnName("email_active");

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasColumnName("email_address")
                    .HasMaxLength(255);

                entity.Property(e => e.EmailComment)
                    .HasColumnName("email_comment")
                    .HasMaxLength(255);

                entity.Property(e => e.EmailExclude).HasColumnName("email_exclude");

                entity.Property(e => e.EmailPrimary).HasColumnName("email_primary");

                entity.Property(e => e.EmailSendCode)
                    .HasColumnName("email_send_code")
                    .HasMaxLength(255);

                entity.Property(e => e.EmailSendTo).HasColumnName("email_send_to");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronGroup>(entity =>
            {
                entity.ToTable("pm_patron_group");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.GroupActive).HasColumnName("group_active");

                entity.Property(e => e.GroupId).HasColumnName("group_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronIdent>(entity =>
            {
                entity.HasKey(e => e.PatronIdentId)
                    .HasName("PK__pm_patro__1925F0833313EF9E");

                entity.ToTable("pm_patron_ident");

                entity.Property(e => e.PatronIdentId)
                    .HasColumnName("patron_ident_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CountryId)
                    .HasColumnName("country_id")
                    .HasMaxLength(255);

                entity.Property(e => e.IdentActive).HasColumnName("ident_active");

                entity.Property(e => e.IdentExp)
                    .HasColumnName("ident_exp")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdentId).HasColumnName("ident_id");

                entity.Property(e => e.IdentImage)
                    .HasColumnName("ident_image")
                    .HasColumnType("image");

                entity.Property(e => e.IdentImageUrl)
                    .HasColumnName("ident_image_url")
                    .HasMaxLength(255);

                entity.Property(e => e.IdentNum)
                    .HasColumnName("ident_num")
                    .HasMaxLength(255);

                entity.Property(e => e.IdentVerifiedBy)
                    .HasColumnName("ident_verified_by")
                    .HasMaxLength(255);

                entity.Property(e => e.IdentVerify)
                    .HasColumnName("ident_verify")
                    .HasColumnType("datetime");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.StateProvId)
                    .HasColumnName("state_prov_id")
                    .HasMaxLength(255);

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronImage>(entity =>
            {
                entity.HasKey(e => e.PatronImageId)
                    .HasName("PK__pm_patro__4EE05DBA4524CBE5");

                entity.ToTable("pm_patron_image");

                entity.Property(e => e.PatronImageId)
                    .HasColumnName("patron_image_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.ImageActive).HasColumnName("image_active");

                entity.Property(e => e.ImageBy)
                    .HasColumnName("image_by")
                    .HasMaxLength(255);

                entity.Property(e => e.ImageDateTime)
                    .HasColumnName("image_date_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.ImageId)
                    .HasColumnName("image_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Imageurl)
                    .IsRequired()
                    .HasColumnName("imageurl")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronInfo>(entity =>
            {
                entity.ToTable("pm_patron_info");

                entity.HasIndex(e => e.Id)
                    .HasName("pk_patron_info_id")
                    .IsUnique();

                entity.HasIndex(e => e.PatronId)
                    .HasName("UK_odan5gn6efwg694lm9x6o93qt")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronId)
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.Patronpin)
                    .IsRequired()
                    .HasColumnName("patronpin")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronInfoPatronClub>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronClub })
                    .HasName("PK__pm_patro__4DA2DF0B32550F67");

                entity.ToTable("pm_patron_info_patron_club");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronClub)
                    .HasColumnName("patron_club")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronInfoPatronCustom>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronCustom })
                    .HasName("PK__pm_patro__AC16F671031B5B2E");

                entity.ToTable("pm_patron_info_patron_custom");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronCustom)
                    .HasColumnName("patron_custom")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronInfoPatronGroup>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronGroup })
                    .HasName("PK__pm_patro__F3DF200D99D40F25");

                entity.ToTable("pm_patron_info_patron_group");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronGroup)
                    .HasColumnName("patron_group")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronInfoPatronLink>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronLink })
                    .HasName("PK__pm_patro__67DE7F6DA87614D6");

                entity.ToTable("pm_patron_info_patron_link");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronLink)
                    .HasColumnName("patron_link")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronInfoPatronStop>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronStop })
                    .HasName("PK__pm_patro__94AE3745427FE9AA");

                entity.ToTable("pm_patron_info_patron_stop");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronStop)
                    .HasColumnName("patron_stop")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronInfoPatronTag>(entity =>
            {
                entity.HasKey(e => new { e.PatronInfo, e.PatronTag })
                    .HasName("PK__pm_patro__0892903C40A5A49F");

                entity.ToTable("pm_patron_info_patron_tag");

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronTag)
                    .HasColumnName("patron_tag")
                    .HasColumnType("numeric(19, 0)");
            });

            modelBuilder.Entity<PmPatronLastActivity>(entity =>
            {
                entity.HasKey(e => e.PatronLastActivityId)
                    .HasName("PK__pm_patro__78C6F151EA92EB89");

                entity.ToTable("pm_patron_last_activity");

                entity.Property(e => e.PatronLastActivityId)
                    .HasColumnName("patron_last_activity_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Activity)
                    .HasColumnName("activity")
                    .HasMaxLength(255);

                entity.Property(e => e.ActivityDate)
                    .HasColumnName("activity_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ActivityShortDesc)
                    .HasColumnName("activity_short_desc")
                    .HasMaxLength(255);

                entity.Property(e => e.ActivityType)
                    .HasColumnName("activity_type")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronId)
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronLink>(entity =>
            {
                entity.ToTable("pm_patron_link");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.LinkActive).HasColumnName("link_active");

                entity.Property(e => e.LinkId).HasColumnName("link_id");

                entity.Property(e => e.LinkPatronId).HasColumnName("link_patron_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronName>(entity =>
            {
                entity.ToTable("pm_patron_name");

                entity.HasIndex(e => e.Id)
                    .HasName("pk_patron_name_id")
                    .IsUnique();

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.FamilyName)
                    .HasColumnName("family_name")
                    .HasMaxLength(255);

                entity.Property(e => e.GivenName)
                    .HasColumnName("given_name")
                    .HasMaxLength(255);

                entity.Property(e => e.LanguageId)
                    .HasColumnName("language_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.MiddleName)
                    .HasColumnName("middle_name")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronProfileId)
                    .HasColumnName("patron_profile_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronPhone>(entity =>
            {
                entity.HasKey(e => e.PatronPhoneId)
                    .HasName("PK__pm_patro__7114161A70D183CC");

                entity.ToTable("pm_patron_phone");

                entity.Property(e => e.PatronPhoneId)
                    .HasColumnName("patron_phone_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PhoneActive).HasColumnName("phone_active");

                entity.Property(e => e.PhoneAreaCode)
                    .HasColumnName("phone_area_code")
                    .HasMaxLength(255);

                entity.Property(e => e.PhoneCallTo).HasColumnName("phone_call_to");

                entity.Property(e => e.PhoneComment)
                    .HasColumnName("phone_comment")
                    .HasMaxLength(255);

                entity.Property(e => e.PhoneCountryCode)
                    .HasColumnName("phone_country_code")
                    .HasMaxLength(255);

                entity.Property(e => e.PhoneExclude).HasColumnName("phone_exclude");

                entity.Property(e => e.PhoneExt).HasColumnName("phone_ext");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasColumnName("phone_number")
                    .HasMaxLength(255);

                entity.Property(e => e.PhonePrimary).HasColumnName("phone_primary");

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronPointAccountTransaction>(entity =>
            {
                entity.ToTable("pm_patron_point_account_transaction");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ActivityId)
                    .HasColumnName("activity_id")
                    .HasMaxLength(255);

                entity.Property(e => e.ActivityType)
                    .HasColumnName("activity_type")
                    .HasMaxLength(255);

                entity.Property(e => e.AddBalance)
                    .HasColumnName("add_balance")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.CreateTime)
                    .HasColumnName("create_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.PatrionAccount)
                    .HasColumnName("patrion_account")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronId)
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.RemainBalance)
                    .HasColumnName("remain_balance")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.TransactionType)
                    .HasColumnName("transaction_type")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronPreference>(entity =>
            {
                entity.ToTable("pm_patron_preference");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PreferenceType)
                    .HasColumnName("preference_type")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PreferenceValue)
                    .HasColumnName("preference_value")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronPreferenceType>(entity =>
            {
                entity.ToTable("pm_patron_preference_type");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CompanyCode)
                    .IsRequired()
                    .HasColumnName("company_code")
                    .HasMaxLength(255);

                entity.Property(e => e.PreferenceTypeKeyword)
                    .IsRequired()
                    .HasColumnName("preference_type_keyword")
                    .HasMaxLength(255);

                entity.Property(e => e.PreferenceTypeName)
                    .IsRequired()
                    .HasColumnName("preference_type_name")
                    .HasMaxLength(255);

                entity.Property(e => e.PropertyCode)
                    .IsRequired()
                    .HasColumnName("property_code")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronProfile>(entity =>
            {
                entity.ToTable("pm_patron_profile");

                entity.HasIndex(e => e.Id)
                    .HasName("pk_patron_profile_id")
                    .IsUnique();

                entity.HasIndex(e => new { e.ProfileRank, e.PatronInfo })
                    .HasName("IDX_pm_patron_profile_patron_info");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.CtrStatus)
                    .HasColumnName("ctr_status")
                    .HasMaxLength(255);

                entity.Property(e => e.FamilyName)
                    .HasColumnName("family_name")
                    .HasMaxLength(255);

                entity.Property(e => e.GenderType)
                    .HasColumnName("gender_type")
                    .HasMaxLength(255);

                entity.Property(e => e.GeographicId)
                    .HasColumnName("geographic_id")
                    .HasMaxLength(255);

                entity.Property(e => e.GivenName)
                    .HasColumnName("given_name")
                    .HasMaxLength(255);

                entity.Property(e => e.HeightUomId)
                    .HasColumnName("height_uom_id")
                    .HasMaxLength(255);

                entity.Property(e => e.HeightValue).HasColumnName("height_value");

                entity.Property(e => e.IsCreditCustomer).HasColumnName("is_credit_customer");

                entity.Property(e => e.IsGamingCustomer).HasColumnName("is_gaming_customer");

                entity.Property(e => e.IsLocked).HasColumnName("is_locked");

                entity.Property(e => e.JunketId)
                    .HasColumnName("junket_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.JunketRepId)
                    .HasColumnName("junket_rep_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.LanguageId)
                    .HasColumnName("language_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.MaritalStatus)
                    .HasColumnName("marital_status")
                    .HasMaxLength(255);

                entity.Property(e => e.MiddleName)
                    .HasColumnName("middle_name")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.ProfileActive).HasColumnName("profile_active");

                entity.Property(e => e.ProfileAge).HasColumnName("profile_age");

                entity.Property(e => e.ProfileAnniversary)
                    .HasColumnName("profile_anniversary")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProfileBirthday)
                    .HasColumnName("profile_birthday")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProfileEye)
                    .HasColumnName("profile_eye")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileFullName)
                    .HasColumnName("profile_full_name")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileGeneration)
                    .HasColumnName("profile_generation")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileHair)
                    .HasColumnName("profile_hair")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileLastPlay)
                    .HasColumnName("profile_last_play")
                    .HasColumnType("datetime");

                entity.Property(e => e.ProfileMaiden)
                    .HasColumnName("profile_maiden")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfilePreferred)
                    .HasColumnName("profile_preferred")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileRank)
                    .HasColumnName("profile_rank")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileSkin)
                    .HasColumnName("profile_skin")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileSuffix)
                    .HasColumnName("profile_suffix")
                    .HasMaxLength(255);

                entity.Property(e => e.ProfileTitle)
                    .HasColumnName("profile_title")
                    .HasMaxLength(255);

                entity.Property(e => e.Profilevip).HasColumnName("profilevip");

                entity.Property(e => e.ProgramId)
                    .HasColumnName("program_id")
                    .HasMaxLength(255);

                entity.Property(e => e.SoftMember).HasColumnName("soft_member");

                entity.Property(e => e.Version).HasColumnName("version");

                entity.Property(e => e.WeightUomId)
                    .HasColumnName("weight_uom_id")
                    .HasMaxLength(255);

                entity.Property(e => e.WeightValue).HasColumnName("weight_value");
            });

            modelBuilder.Entity<PmPatronProfileExtension>(entity =>
            {
                entity.ToTable("pm_patron_profile_extension");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Adt).HasColumnName("adt");

                entity.Property(e => e.CustomerWinloss).HasColumnName("customer_winloss");

                entity.Property(e => e.IsReceiveEmail).HasColumnName("is_receive_email");

                entity.Property(e => e.IsReceivesms).HasColumnName("is_receivesms");

                entity.Property(e => e.MrketingHost)
                    .HasColumnName("mrketing_host")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.PatronProfileId)
                    .HasColumnName("patron_profile_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.TotalReInvestmentBudget)
                    .HasColumnName("total_re_investment_budget")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");

                entity.Property(e => e.WeChat)
                    .HasColumnName("we_chat")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<PmPatronRelation>(entity =>
            {
                entity.ToTable("pm_patron_relation");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.EmployeeId)
                    .IsRequired()
                    .HasColumnName("employee_id")
                    .HasMaxLength(32);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.RelationActive).HasColumnName("relation_active");

                entity.Property(e => e.RelationId)
                    .HasColumnName("relation_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronSign>(entity =>
            {
                entity.ToTable("pm_patron_sign");

                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.Agency)
                    .IsRequired()
                    .HasColumnName("agency")
                    .HasMaxLength(100);

                entity.Property(e => e.CompanyCode)
                    .IsRequired()
                    .HasColumnName("company_code")
                    .HasMaxLength(100);

                entity.Property(e => e.CreatedTime)
                    .HasColumnName("created_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.PatronId)
                    .IsRequired()
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.PropertyCode)
                    .IsRequired()
                    .HasColumnName("property_code")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<PmPatronSignitureImage>(entity =>
            {
                entity.HasKey(e => e.PatronIdentSignitureId)
                    .HasName("PK__pm_patro__D83FA7944382E00A");

                entity.ToTable("pm_patron_signiture_image");

                entity.Property(e => e.PatronIdentSignitureId)
                    .HasColumnName("patron_ident_signiture_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronInfo)
                    .HasColumnName("patron_info")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.SignitureImage)
                    .HasColumnName("signiture_image")
                    .HasColumnType("image");

                entity.Property(e => e.SignitureImageUrl)
                    .HasColumnName("signiture_image_url")
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<PmPatronStop>(entity =>
            {
                entity.ToTable("pm_patron_stop");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AnyAttribute)
                    .HasColumnName("any_attribute")
                    .HasMaxLength(255);

                entity.Property(e => e.StopAction)
                    .IsRequired()
                    .HasColumnName("stop_action")
                    .HasMaxLength(255);

                entity.Property(e => e.StopActive).HasColumnName("stop_active");

                entity.Property(e => e.StopId).HasColumnName("stop_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPatronTag>(entity =>
            {
                entity.HasKey(e => e.PatronTagId)
                    .HasName("PK__pm_patro__D7562CBBFB31D7CB");

                entity.ToTable("pm_patron_tag");

                entity.Property(e => e.PatronTagId)
                    .HasColumnName("patron_tag_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.PatronTagActive).HasColumnName("patron_tag_active");

                entity.Property(e => e.TagName)
                    .IsRequired()
                    .HasColumnName("tag_name")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmProfileAttribute>(entity =>
            {
                entity.ToTable("pm_profile_attribute");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.AttributeId)
                    .IsRequired()
                    .HasColumnName("attribute_id")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronProfile)
                    .HasColumnName("patron_profile")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.ProfileAttributeValue)
                    .IsRequired()
                    .HasColumnName("profile_attribute_value")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmPromotion>(entity =>
            {
                entity.ToTable("pm_promotion");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CouponType)
                    .IsRequired()
                    .HasColumnName("coupon_type")
                    .HasMaxLength(255);

                entity.Property(e => e.Couponid)
                    .HasColumnName("couponid")
                    .HasMaxLength(255);

                entity.Property(e => e.GiftNumber)
                    .HasColumnName("gift_number")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronId)
                    .IsRequired()
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.Property)
                    .HasColumnName("property")
                    .HasMaxLength(255);

                entity.Property(e => e.Uid)
                    .HasColumnName("uid")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmReInvestmentExpense>(entity =>
            {
                entity.ToTable("pm_re_investment_expense");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ContentId)
                    .HasColumnName("content_id")
                    .HasMaxLength(255);

                entity.Property(e => e.ContentType)
                    .HasColumnName("content_type")
                    .HasMaxLength(255);

                entity.Property(e => e.ExpenseDate)
                    .HasColumnName("expense_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ExpenseType)
                    .HasColumnName("expense_type")
                    .HasMaxLength(255);

                entity.Property(e => e.ExpenseVaule).HasColumnName("expense_vaule");

                entity.Property(e => e.PatroninfoId)
                    .HasColumnName("patroninfo_id")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmRelation>(entity =>
            {
                entity.HasKey(e => e.RelationId)
                    .HasName("PK__pm_relat__C409F323DD708BEE");

                entity.ToTable("pm_relation");

                entity.Property(e => e.RelationId)
                    .HasColumnName("relation_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.RelationActive).HasColumnName("relation_active");

                entity.Property(e => e.RelationName)
                    .IsRequired()
                    .HasColumnName("relation_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmStandardRatingInformation>(entity =>
            {
                entity.ToTable("pm_standard_rating_information");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ActWin)
                    .HasColumnName("act_win")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.CustomerId)
                    .HasColumnName("customer_id")
                    .HasMaxLength(255);

                entity.Property(e => e.GamingDay)
                    .HasColumnName("gaming_day")
                    .HasColumnType("datetime");

                entity.Property(e => e.OperationDate)
                    .HasColumnName("operation_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.OperationType)
                    .HasColumnName("operation_type")
                    .HasMaxLength(255);

                entity.Property(e => e.S2s)
                    .HasColumnName("s2s")
                    .HasColumnType("text");

                entity.Property(e => e.TableId)
                    .HasColumnName("table_id")
                    .HasMaxLength(255);

                entity.Property(e => e.TheoWin)
                    .HasColumnName("theo_win")
                    .HasColumnType("numeric(19, 0)");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmStandardRatings2sLog>(entity =>
            {
                entity.ToTable("pm_standard_ratings2s_log");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CustomerId)
                    .HasColumnName("customer_id")
                    .HasMaxLength(255);

                entity.Property(e => e.OperationDate)
                    .HasColumnName("operation_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.OperationType)
                    .HasColumnName("operation_type")
                    .HasMaxLength(255);

                entity.Property(e => e.S2sSchemaInfo)
                    .HasColumnName("s2s_schema_info")
                    .HasColumnType("text");

                entity.Property(e => e.TableId)
                    .HasColumnName("table_id")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmStop>(entity =>
            {
                entity.HasKey(e => e.StopId)
                    .HasName("PK__pm_stop__86FBE1820FBF5CE3");

                entity.ToTable("pm_stop");

                entity.Property(e => e.StopId)
                    .HasColumnName("stop_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.StopActive).HasColumnName("stop_active");

                entity.Property(e => e.StopName)
                    .IsRequired()
                    .HasColumnName("stop_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmTrip>(entity =>
            {
                entity.HasKey(e => e.PatronTripId)
                    .HasName("PK__pm_trip__BB170ED98992C3F7");

                entity.ToTable("pm_trip");

                entity.Property(e => e.PatronTripId)
                    .HasColumnName("patron_trip_id")
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.CloseTime)
                    .HasColumnName("close_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(255);

                entity.Property(e => e.Host)
                    .HasColumnName("host")
                    .HasMaxLength(255);

                entity.Property(e => e.PatronId)
                    .HasColumnName("patron_id")
                    .HasMaxLength(255);

                entity.Property(e => e.PlanArriveDate)
                    .HasColumnName("plan_arrive_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PlanLeaveDate)
                    .HasColumnName("plan_leave_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.StartTime)
                    .HasColumnName("start_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(255);

                entity.Property(e => e.TenantId).HasColumnName("tenant_id");

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmTripAction>(entity =>
            {
                entity.HasKey(e => e.PatronTripActionId)
                    .HasName("PK__pm_trip___F70954CDF71DAA6C");

                entity.ToTable("pm_trip_action");

                entity.Property(e => e.PatronTripActionId)
                    .HasColumnName("patron_trip_action_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CreatedBy)
                    .HasColumnName("created_by")
                    .HasMaxLength(255);

                entity.Property(e => e.CreatedTime)
                    .HasColumnName("created_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.PatronTripId)
                    .HasColumnName("patron_trip_id")
                    .HasMaxLength(36);

                entity.Property(e => e.TripAction)
                    .HasColumnName("trip_action")
                    .HasMaxLength(255);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<PmUsages>(entity =>
            {
                entity.HasKey(e => e.UsageId)
                    .HasName("PK__pm_usage__B6B13A02D0BD3F5D");

                entity.ToTable("pm_usages");

                entity.Property(e => e.UsageId)
                    .HasColumnName("usage_id")
                    .HasColumnType("numeric(19, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.UsageActive).HasColumnName("usage_active");

                entity.Property(e => e.UsageName)
                    .IsRequired()
                    .HasColumnName("usage_name")
                    .HasMaxLength(32);

                entity.Property(e => e.Version).HasColumnName("version");
            });

            modelBuilder.Entity<RatingCustomerRatingSummary>(entity =>
            {
                entity.ToTable("Rating_CustomerRatingSummary");

                entity.Property(e => e.Id)
                    .HasMaxLength(36)
                    .ValueGeneratedNever();

                entity.Property(e => e.CreatedTime).HasColumnType("datetime");

                entity.Property(e => e.CustomerId)
                    .IsRequired()
                    .HasMaxLength(36);

                entity.Property(e => e.LatestTripRatingCount).HasDefaultValueSql("((0))");

                entity.Property(e => e.LatestTripTheoreticalWin)
                    .HasColumnType("decimal(18, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LatestTripWinLoss)
                    .HasColumnType("decimal(18, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LtdtheoreticalWin)
                    .HasColumnName("LTDTheoreticalWin")
                    .HasColumnType("decimal(18, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LtdwinLoss)
                    .HasColumnName("LTDWinLoss")
                    .HasColumnType("decimal(18, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.UpdatedTime).HasColumnType("datetime");
            });
        }
    }
}
