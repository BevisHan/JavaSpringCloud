using EntityFramework.DbContextScope.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PMDbContext : DbContext, IDbContext
    {
        
    }
}