﻿using Augmentum.PatronManagement.Core.Models;
using System.Linq;

namespace Augmentum.PatronManagement.Core.Db
{
    public interface IReadDbFacade
    {
        IQueryable<PmPatronInfo> PmPatronInfos { get; }
        IQueryable<PmPatronProfile> PmPatronProfiles { get; }
        IQueryable<PmPatronProfileExtension> PmPatronProfileExtensions { get; }
        IQueryable<PmMarketingHost> PmMarketingHosts { get; }
        IQueryable<PmPatronSignitureImage> PmPatronSignitureImages { get; }
        IQueryable<PmPatronName> PmPatronNames { get; }

    }
}
