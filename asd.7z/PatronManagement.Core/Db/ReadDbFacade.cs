﻿﻿using Augmentum.PatronManagement.Core.Models;
using System;
using System.Linq;

namespace Augmentum.PatronManagement.Core.Db
{
    public class ReadDbFacade : IReadDbFacade, IDisposable
    {
        private readonly PMDbContext _readDbContext;

        public ReadDbFacade(PMDbContext readDbContext)
        {
            _readDbContext = readDbContext;
        }

        public IQueryable<PmPatronInfo> PmPatronInfos => _readDbContext.PmPatronInfo;
        public IQueryable<PmPatronProfile> PmPatronProfiles => _readDbContext.PmPatronProfile;
        public IQueryable<PmPatronName> PmPatronNames => _readDbContext.PmPatronName;
        public IQueryable<PmPatronProfileExtension> PmPatronProfileExtensions => _readDbContext.PmPatronProfileExtension;
        public IQueryable<PmMarketingHost> PmMarketingHosts => _readDbContext.PmMarketingHost;
        public IQueryable<PmPatronSignitureImage> PmPatronSignitureImages => _readDbContext.PmPatronSignitureImage;
        public void Dispose()
        {
            _readDbContext.Dispose();
        }
    }
}
