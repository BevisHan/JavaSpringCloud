﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronCustom
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public int PatronCustomId { get; set; }
        public bool PatronCustomInactive { get; set; }
        public string PatronCustomValue { get; set; }
        public int? Version { get; set; }
    }
}
