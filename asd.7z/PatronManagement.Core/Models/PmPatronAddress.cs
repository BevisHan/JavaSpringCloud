﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmPatronAddress {
        public decimal PatronAddressId { get; set; }
        public string AddressLineValue { get; set; }
        public bool? AddressActive { get; set; }
        public string AddressCareOf { get; set; }
        public string AddressCity { get; set; }
        public string AddressComment { get; set; }
        public bool? AddressExclude { get; set; }
        public string AddressMailCode { get; set; }
        public bool? AddressMailTo { get; set; }
        public bool? AddressPlain { get; set; }
        public bool? AddressPrimary { get; set; }
        public bool? AddressRtnMail { get; set; }
        public string AddressSuburb { get; set; }
        public string AnyAttribute { get; set; }
        public string CountryId { get; set; }
        public string PostCodeExt { get; set; }
        public string PostCodeId { get; set; }
        public string StateProvId { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
