using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public class PatronSearchResult
    {
        public PatronSearchResult()
        {
            patronInfo = new List<patronInfo>();
        }
        public IList<patronInfo> patronInfo { get; set; }
        public int totalCount { get; set; }

        public IList<patronInfo> ConvertToResponseModel(IList<PatronInfoView> PatronInfoList)
        {
            IList<patronInfo> response = new List<patronInfo>();

            foreach (PatronInfoView patronInfo in PatronInfoList)
            {
                response.Add(new patronInfo
                {
                    Any = new List<string>
                    {
                        patronInfo.AnyAttribute
                    }.ToArray(),
                    patronId = new patronId
                    {
                        Value = patronInfo.PatronId
                    },
                    patronProfile = new patronProfile
                    {
                        maritalStatus = (patronInfo.MaritalStatus != null) ? ((patronProfileMaritalStatus)(patronProfileMaritalStatus.Parse(typeof(patronProfileMaritalStatus), patronInfo.MaritalStatus))) : ((patronProfileMaritalStatus)(patronProfileMaritalStatus.Parse(typeof(patronProfileMaritalStatus), "Unknown"))),
                        ctrStatus = (patronInfo.CtrStatus != null) ? (patronProfileCtrStatus)(patronProfileCtrStatus.Parse(typeof(patronProfileCtrStatus), patronInfo.CtrStatus)) : (patronProfileCtrStatus)(patronProfileCtrStatus.Parse(typeof(patronProfileCtrStatus), "Prohibited")),
                        genderType = (patronProfileGenderType)(patronProfileGenderType.Parse(typeof(patronProfileGenderType), patronInfo.GenderType)),
                        Any = (new List<PatronProfileExtension>
                        {
                            new PatronProfileExtension
                            {
                                adt = (decimal)patronInfo.Adt,
                                customerWinloss = (decimal)patronInfo.CustomerWinloss,
                                isReceiveEmail = patronInfo.IsReceiveEmail,
                                isReceiveSMS = patronInfo.IsReceivesms,
                                marketingHost = new marketingHost
                                {
                                    marketerName = patronInfo.MarketerName,
                                    phoneNumber = patronInfo.PhoneNumber,
                                    version = (int)patronInfo.HostVersion
                                }
                            }
                        }).ToArray(),
                        geographicId = patronInfo.GeographicId,
                        isCreditCustomer = patronInfo.IsCreditCustomer,
                        isGamingCustomer = patronInfo.IsGamingCustomer,
                        isLocked = patronInfo.IsLocked,
                        isVip = patronInfo.IsVip,
                        junketId = patronInfo.JunketId.ToString(),
                        junketRepId = patronInfo.JunketRepId.ToString(),
                        languageId = patronInfo.LanguageId.ToString(),
                        profileActive = patronInfo.ProfileActive,
                        profileAge = patronInfo.ProfileAge,
                        profileAnniversary = patronInfo.ProfileAnniversary,
                        profileBirthday = patronInfo.ProfileBirthday,
                        profileEye = patronInfo.ProfileEye,
                        profileFirstName = patronInfo.ProfileFirstName,
                        profileFullName = patronInfo.ProfileFullName,
                        profileGeneration = patronInfo.ProfileGeneration,
                        profileHair = patronInfo.ProfileHair,
                        profileHeight = new patronProfileProfileHeight
                        {
                            uomId = patronInfo.HeightUomId,
                            Value = patronInfo.HeightValue
                        },
                        profileLastName = patronInfo.ProfileLastName,
                        profileLastPlay = patronInfo.ProfileLastPlay,
                        profileMaiden = patronInfo.ProfileMaiden,
                        profileMiddleName = patronInfo.ProfileMiddleName,
                        profilePreferred = patronInfo.ProfilePreferred,
                        profileRank = patronInfo.ProfileRank,
                        profileSkin = patronInfo.ProfileSkin,
                        profileSuffix = patronInfo.ProfileSuffix,
                        profileTitle = patronInfo.ProfileTitle,
                        profileVIP = patronInfo.Profilevip,
                        profileWeight = new patronProfileProfileWeight
                        {
                            uomId = patronInfo.WeightUomId,
                            Value = patronInfo.WeightValue
                        },
                        programId = patronInfo.ProgramId,
                        softMember = patronInfo.SoftMember
                    },
                });
            }
            return response;
        }
    }
}

