﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmLink {
        public decimal LinkId { get; set; }
        public bool? LinkActive { get; set; }
        public string LinkName { get; set; }
        public int? Version { get; set; }
    }
}
