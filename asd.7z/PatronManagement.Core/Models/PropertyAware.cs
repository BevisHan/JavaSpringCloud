namespace Augmentum.PatronManagement.Core.Models
{
    public class PropertyAware
    {
        public string companyCode { get; set; }
        public string propertyCode { get; set; }
    }
}