﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronTag
    {
        public decimal PatronTagId { get; set; }
        public bool? PatronTagActive { get; set; }
        public string TagName { get; set; }
        public int? Version { get; set; }
    }
}
