﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronComment
    {
        public decimal PatronCommentId { get; set; }
        public string AnyAttribute { get; set; }
        public bool? CommentActive { get; set; }
        public string CommentBy { get; set; }
        public DateTime? CommentDateTime { get; set; }
        public DateTime? CommentExp { get; set; }
        public bool? CommentMandatory { get; set; }
        public int? CommentPriority { get; set; }
        public string CommentSource { get; set; }
        public string CommentText { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
