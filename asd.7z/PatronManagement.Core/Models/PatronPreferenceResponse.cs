namespace Augmentum.PatronManagement.Core.Models
{
    public class PatronPreferenceResponse
    {
        private string preferenceValue { get; set;}

        private PmPatronPreferenceType pmPatronPreferenceType { get; set;}
    }
}