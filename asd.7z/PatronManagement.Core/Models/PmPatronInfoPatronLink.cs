﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronInfoPatronLink
    {
        public decimal PatronInfo { get; set; }
        public decimal PatronLink { get; set; }
    }
}
