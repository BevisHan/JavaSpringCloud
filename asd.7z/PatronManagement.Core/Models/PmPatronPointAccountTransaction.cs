﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronPointAccountTransaction
    {
        public decimal Id { get; set; }
        public string ActivityId { get; set; }
        public string ActivityType { get; set; }
        public decimal AddBalance { get; set; }
        public DateTime? CreateTime { get; set; }
        public string PatronId { get; set; }
        public decimal RemainBalance { get; set; }
        public string TransactionType { get; set; }
        public int? Version { get; set; }
        public decimal? PatrionAccount { get; set; }
    }
}
