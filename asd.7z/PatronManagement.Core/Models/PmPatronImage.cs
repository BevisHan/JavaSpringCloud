﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronImage
    {
        public decimal PatronImageId { get; set; }
        public string AnyAttribute { get; set; }
        public bool? ImageActive { get; set; }
        public string ImageBy { get; set; }
        public DateTime? ImageDateTime { get; set; }
        public decimal? ImageId { get; set; }
        public string Imageurl { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
