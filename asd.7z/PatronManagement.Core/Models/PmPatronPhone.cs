﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronPhone
    {
        public decimal PatronPhoneId { get; set; }
        public string AnyAttribute { get; set; }
        public bool? PhoneActive { get; set; }
        public string PhoneAreaCode { get; set; }
        public bool? PhoneCallTo { get; set; }
        public string PhoneComment { get; set; }
        public string PhoneCountryCode { get; set; }
        public bool? PhoneExclude { get; set; }
        public int? PhoneExt { get; set; }
        public string PhoneNumber { get; set; }
        public bool? PhonePrimary { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
