﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmPatronAccount {
        public decimal Id { get; set; }
        public double? AccountAvailability { get; set; }
        public decimal AccountBalance { get; set; }
        public decimal? AccountId { get; set; }
        public string AccountType { get; set; }
        public string AnyAttribute { get; set; }
        public int CompItemId { get; set; }
        public int CompLocId { get; set; }
        public double? ForeignAvailability { get; set; }
        public double? ForeignBalance { get; set; }
        public DateTime? ForeignExpiry { get; set; }
        public int ForeignId { get; set; }
        public double? ForeignRate { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
        public DateTime? UpdateTime { get; set; }
    }
}
