﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronClub
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public bool? ClubActive { get; set; }
        public DateTime? ClubEffDate { get; set; }
        public DateTime? ClubExpDate { get; set; }
        public int ClubId { get; set; }
        public int? Version { get; set; }
    }
}
