﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmAccountExtension {
        public decimal AccountId { get; set; }
        public bool? AccountActive { get; set; }
        public double? AccountAvailability { get; set; }
        public double AccountBalance { get; set; }
        public string AccountName { get; set; }
        public string AccountType { get; set; }
        public int ForeignId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronAccountExtension { get; set; }
    }
}
