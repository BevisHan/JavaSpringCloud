﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronSign
    {
        public string Id { get; set; }
        public string PatronId { get; set; }
        public string Agency { get; set; }
        public string CompanyCode { get; set; }
        public string PropertyCode { get; set; }
        public DateTime CreatedTime { get; set; }
    }
}
