﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronEmail
    {
        public decimal PatronEmailId { get; set; }
        public string AnyAttribute { get; set; }
        public bool? EmailActive { get; set; }
        public string EmailAddress { get; set; }
        public string EmailComment { get; set; }
        public bool? EmailExclude { get; set; }
        public bool? EmailPrimary { get; set; }
        public string EmailSendCode { get; set; }
        public bool? EmailSendTo { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
