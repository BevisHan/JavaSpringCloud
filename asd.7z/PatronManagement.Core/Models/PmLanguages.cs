﻿namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmLanguages
    {
        public decimal LanguageId { get; set; }
        public bool? LanguageActive { get; set; }
        public string LanguageName { get; set; }
        public int? Version { get; set; }
        public string AnyAttribute { get; set; }
    }
}
