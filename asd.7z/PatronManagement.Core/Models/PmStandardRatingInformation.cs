﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmStandardRatingInformation
    {
        public decimal Id { get; set; }
        public decimal ActWin { get; set; }
        public string CustomerId { get; set; }
        public DateTime? GamingDay { get; set; }
        public DateTime? OperationDate { get; set; }
        public string OperationType { get; set; }
        public string S2s { get; set; }
        public string TableId { get; set; }
        public decimal TheoWin { get; set; }
        public int? Version { get; set; }
    }
}
