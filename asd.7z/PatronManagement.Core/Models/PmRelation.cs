﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmRelation
    {
        public decimal RelationId { get; set; }
        public bool? RelationActive { get; set; }
        public string RelationName { get; set; }
        public int? Version { get; set; }
    }
}
