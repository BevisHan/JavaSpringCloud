﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class MarkerCustomerMarkerInfo {
        public string Id { get; set; }
        public string MarkerId { get; set; }
        public string MarkerDocumentId { get; set; }
        public string CustomerId { get; set; }
        public DateTime? IssueDate { get; set; }
        public string Currency { get; set; }
        public decimal? Amount { get; set; }
        public string Status { get; set; }
        public int? TenantId { get; set; }
    }
}
