﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronSignitureImage
    {
        public decimal PatronIdentSignitureId { get; set; }
        public string AnyAttribute { get; set; }
        public byte[] SignitureImage { get; set; }
        public string SignitureImageUrl { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
