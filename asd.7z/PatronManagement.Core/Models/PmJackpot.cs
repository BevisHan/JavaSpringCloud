﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmJackpot {
        public decimal Id { get; set; }
        public bool Active { get; set; }
        public bool? Blackout { get; set; }
        public string Code { get; set; }
        public decimal? CurrentValue { get; set; }
        public bool? DisplayJackpot { get; set; }
        public DateTime? LastUpdated { get; set; }
        public DateTime? NextdrawPeriod { get; set; }
        public string PatronId { get; set; }
        public int? Version { get; set; }
    }
}
