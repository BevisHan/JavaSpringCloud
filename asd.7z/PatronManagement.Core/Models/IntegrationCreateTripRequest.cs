namespace Augmentum.PatronManagement.Core.Models
{
    public class IntegrationCreateTripRequest : PropertyAware
    {
        public string patronId { get; set; }
        public long planArriveDate { get; set; }
        public long planLeaveDate { get; set; }
    }
}