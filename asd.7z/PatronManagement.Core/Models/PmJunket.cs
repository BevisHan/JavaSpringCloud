﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmJunket {
        public decimal JunketId { get; set; }
        public bool? JunketActive { get; set; }
        public DateTime? JunketEndDate { get; set; }
        public string JunketName { get; set; }
        public bool? JunketNotify { get; set; }
        public decimal? JunketRepId { get; set; }
        public DateTime? JunketStrDate { get; set; }
        public int? Version { get; set; }
    }
}
