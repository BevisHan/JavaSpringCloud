﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronInfoPatronCustom
    {
        public decimal PatronInfo { get; set; }
        public decimal PatronCustom { get; set; }
    }
}
