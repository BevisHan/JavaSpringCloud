﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronInfoPatronGroup
    {
        public decimal PatronInfo { get; set; }
        public decimal PatronGroup { get; set; }
    }
}
