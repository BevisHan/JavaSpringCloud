namespace Augmentum.PatronManagement.Core.Models
{
    public class PatronName
    {
        public string familyName { get; set; }
        public string givenName { get; set; }
        public Language language { get; set; }
    }
    
    public class Language
    {
        public bool languageActive { get; set; }
        public long languageId { get; set; }
        public string languageName { get; set; }
    }
}