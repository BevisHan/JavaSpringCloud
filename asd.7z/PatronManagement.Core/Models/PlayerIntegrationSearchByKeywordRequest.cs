namespace Augmentum.PatronManagement.Core.Models
{
    public class PlayerIntegrationSearchByKeywordRequest
    {
        public PlayerIntegrationSearchByKeywordCriteria criteria { get; set; }

        public PlayerSortByEnum sortBy { get; set; }

        public Pagination pager { get; set; }
    }
    
    public class PlayerIntegrationSearchByKeywordCriteria
    {
        public string Keyword { get; set; }
        public string language { get; set; }
        public string state { get; set; }
    }
    
    public enum PlayerSortByEnum
    {
        CUSTOMER_CODE=0,

        PLAYER_NAME_ASC=1,

        PLAYER_NAME_DESC=2,

        PLAYER_ID_ASC=3,

        PLAYER_ID_DESC=4,

        DATE_OF_BIRTH_ASC=5,

        DATE_OF_BIRTH_DESC=6,

        COUNTRY_ASC=7,

        COUNTRY_DESC=8
    }

    public class Pagination
    {
        /// <summary>
        /// Gets or sets current page.
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// Gets or sets every page size.
        /// </summary>
        public int PageSize { get; set; }
    }
}