﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmReInvestmentExpense
    {
        public decimal Id { get; set; }
        public string ContentId { get; set; }
        public string ContentType { get; set; }
        public DateTime? ExpenseDate { get; set; }
        public string ExpenseType { get; set; }
        public double? ExpenseVaule { get; set; }
        public int? Version { get; set; }
        public decimal? PatroninfoId { get; set; }
    }
}
