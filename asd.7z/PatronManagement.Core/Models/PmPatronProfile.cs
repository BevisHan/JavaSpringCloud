﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronProfile
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public string CtrStatus { get; set; }
        public string FamilyName { get; set; }
        public string GenderType { get; set; }
        public string GeographicId { get; set; }
        public string GivenName { get; set; }
        public string HeightUomId { get; set; }
        public int HeightValue { get; set; }
        public decimal? JunketId { get; set; }
        public decimal? JunketRepId { get; set; }
        public string MaritalStatus { get; set; }
        public string MiddleName { get; set; }
        public bool? ProfileActive { get; set; }
        public DateTime? ProfileAnniversary { get; set; }
        public DateTime? ProfileBirthday { get; set; }
        public string ProfileEye { get; set; }
        public string ProfileFullName { get; set; }
        public string ProfileGeneration { get; set; }
        public string ProfileHair { get; set; }
        public DateTime? ProfileLastPlay { get; set; }
        public string ProfileMaiden { get; set; }
        public string ProfilePreferred { get; set; }
        public string ProfileRank { get; set; }
        public string ProfileSkin { get; set; }
        public string ProfileSuffix { get; set; }
        public string ProfileTitle { get; set; }
        public bool? Profilevip { get; set; }
        public string ProgramId { get; set; }
        public int? Version { get; set; }
        public string WeightUomId { get; set; }
        public int WeightValue { get; set; }
        public decimal? LanguageId { get; set; }
        public decimal? PatronInfo { get; set; }
        public bool? IsGamingCustomer { get; set; }
        public int ProfileAge { get; set; }
        public bool IsCreditCustomer { get; set; }
        public bool SoftMember { get; set; }
        public bool IsLocked { get; set; }
    }
}
