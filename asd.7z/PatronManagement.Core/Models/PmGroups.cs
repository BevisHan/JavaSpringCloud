﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmGroups {
        public decimal GroupId { get; set; }
        public bool? GroupActive { get; set; }
        public DateTime? GroupEffDate { get; set; }
        public DateTime? GroupExpDate { get; set; }
        public string GroupName { get; set; }
        public bool? GroupNotify { get; set; }
        public int? Version { get; set; }
    }
}
