﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronPreference
    {
        public decimal Id { get; set; }
        public string PreferenceValue { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
        public decimal PreferenceType { get; set; }
        public PmPatronPreferenceType pmPatronPreferenceType { get; set;}
    }
}
