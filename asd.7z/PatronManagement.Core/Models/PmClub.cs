﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmClub {
        public decimal ClubId { get; set; }
        public bool? ClubActive { get; set; }
        public string ClubName { get; set; }
        public bool? ClubNotify { get; set; }
        public int? Version { get; set; }
    }
}
