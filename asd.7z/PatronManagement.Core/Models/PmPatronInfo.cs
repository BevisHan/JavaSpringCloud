﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronInfo
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public string PatronId { get; set; }
        public string Patronpin { get; set; }
        public int? Version { get; set; }
    }
}
