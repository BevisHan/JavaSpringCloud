﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmPatronCard {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public bool? CardActive { get; set; }
        public DateTime? CardExp { get; set; }
        public string CardId { get; set; }
        public bool? CardLost { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
