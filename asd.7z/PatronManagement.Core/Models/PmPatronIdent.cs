﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronIdent
    {
        public decimal PatronIdentId { get; set; }
        public string AnyAttribute { get; set; }
        public string CountryId { get; set; }
        public bool? IdentActive { get; set; }
        public DateTime? IdentExp { get; set; }
        public int IdentId { get; set; }
        public string IdentNum { get; set; }
        public string IdentVerifiedBy { get; set; }
        public DateTime? IdentVerify { get; set; }
        public string StateProvId { get; set; }
        public byte[] IdentImage { get; set; }
        public string IdentImageUrl { get; set; }
        public decimal? UsageId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
