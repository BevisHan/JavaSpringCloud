namespace Augmentum.PatronManagement.Core.Models
{
    public class PlayerPreference
    {
        public PlayerPreference()
        {
            preferenceType = new PlayerPreferenceType();
        }

        public string patronId { get; set; }
        public PlayerPreferenceType preferenceType { get; set; }
        public string preferenceValue { get; set; }
    }

    public class PlayerPreferenceType
    {
        public string companyCode { get; set; }
        public string preferenceTypeKeyword { get; set; }
        public string preferenceTypeName { get; set; }
        public string propertyCode { get; set; }
    }
}
