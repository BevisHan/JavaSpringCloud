﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronRelation
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public string EmployeeId { get; set; }
        public bool? RelationActive { get; set; }
        public decimal RelationId { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
