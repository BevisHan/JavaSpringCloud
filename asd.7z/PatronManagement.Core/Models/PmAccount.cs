﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmAccount {
        public decimal AccountId { get; set; }
        public bool? AccountActive { get; set; }
        public string AccountName { get; set; }
        public string AccountType { get; set; }
        public int ForeignId { get; set; }
        public int? Version { get; set; }
    }
}
