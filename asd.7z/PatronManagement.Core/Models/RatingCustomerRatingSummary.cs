﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class RatingCustomerRatingSummary
    {
        public string Id { get; set; }
        public string CustomerId { get; set; }
        public decimal? LtdwinLoss { get; set; }
        public decimal? LtdtheoreticalWin { get; set; }
        public decimal? LatestTripWinLoss { get; set; }
        public decimal? LatestTripTheoreticalWin { get; set; }
        public int? LatestTripRatingCount { get; set; }
        public DateTime CreatedTime { get; set; }
        public DateTime UpdatedTime { get; set; }
    }
}
