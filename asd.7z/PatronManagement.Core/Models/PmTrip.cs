﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmTrip
    {
        public string PatronTripId { get; set; }
        public DateTime? CloseTime { get; set; }
        public string CreatedBy { get; set; }
        public string Host { get; set; }
        public string PatronId { get; set; }
        public DateTime? StartTime { get; set; }
        public string Status { get; set; }
        public int? Version { get; set; }
        public DateTime? PlanArriveDate { get; set; }
        public DateTime? PlanLeaveDate { get; set; }
        public int? TenantId { get; set; }
    }
}
