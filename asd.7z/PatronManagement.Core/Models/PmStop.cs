﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmStop
    {
        public decimal StopId { get; set; }
        public bool? StopActive { get; set; }
        public string StopName { get; set; }
        public int? Version { get; set; }
    }
}
