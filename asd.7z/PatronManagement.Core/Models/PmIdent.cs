﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmIdent {
        public decimal IdentId { get; set; }
        public bool? IdentActive { get; set; }
        public string IdentName { get; set; }
        public int? Version { get; set; }
    }
}
