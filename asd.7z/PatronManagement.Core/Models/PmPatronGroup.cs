﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronGroup
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public bool? GroupActive { get; set; }
        public int GroupId { get; set; }
        public int? Version { get; set; }
    }
}
