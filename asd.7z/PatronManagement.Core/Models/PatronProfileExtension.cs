using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public class marketingHost
    {
        public string marketerName { get; set; }

        public string phoneNumber { get; set; }

        public int version { get; set; }
    }

    public class PatronProfileExtension
    {
        public PatronProfileExtension()
        {
            patronName = new List<PatronName>();
        }

        public bool? isReceiveSMS { get; set; }
        public bool? isReceiveEmail { get; set; }
        public long? totalReInvestmentBudget { get; set; }
        public IList<PatronName> patronName { get; set; }
        public decimal adt { get; set; }
        public marketingHost marketingHost { get; set; }
        public decimal customerWinloss { get; set; }
    }
}
