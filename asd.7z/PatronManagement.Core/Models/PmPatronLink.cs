﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronLink
    {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public bool? LinkActive { get; set; }
        public int LinkId { get; set; }
        public int LinkPatronId { get; set; }
        public int? Version { get; set; }
    }
}
