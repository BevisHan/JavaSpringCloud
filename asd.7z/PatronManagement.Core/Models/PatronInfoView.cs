using System;

namespace Augmentum.PatronManagement.Core.Models
{
    public class PatronInfoView
    {
        public string AnyAttribute { get; set; }
        public string PatronId { get; set; }
        public double? Adt { get; set; }
        public double? CustomerWinloss { get; set; }
        public bool? IsReceivesms { get; set; }
        public bool? IsReceiveEmail { get; set; }
        public string MarketerName { get; set; }
        public string PhoneNumber { get; set; }
        public int? HostVersion { get; set; }
        public decimal? PatronProfileId { get; set; }
        public int? ProfileVersion { get; set; }
        public string WeChat { get; set; }
        public string CtrStatus { get; set; }
        public string GenderType { get; set; }
        public string GeographicId { get; set; }
        public bool IsCreditCustomer { get; set; }
        public bool? IsGamingCustomer { get; set; }
        public bool IsLocked { get; set; }
        public decimal? JunketId { get; set; }
        public decimal? JunketRepId { get; set; }
        public decimal? LanguageId { get; set; }
        public string MaritalStatus { get; set; }
        public bool? ProfileActive { get; set; }
        public int ProfileAge { get; set; }
        public DateTime? ProfileAnniversary { get; set; }
        public DateTime? ProfileBirthday { get; set; }
        public string ProfileEye { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileFullName { get; set; }
        public string ProfileGeneration { get; set; }
        public string ProfileHair { get; set; }
        public string HeightUomId { get; set; }
        public int HeightValue { get; set; }
        public string ProfileLastName { get; set; }
        public DateTime? ProfileLastPlay { get; set; }
        public string ProfileMaiden { get; set; }
        public string ProfileMiddleName { get; set; }
        public string ProfilePreferred { get; set; }
        public string ProfileRank { get; set; }
        public string ProfileSkin { get; set; }
        public string ProfileSuffix { get; set; }
        public string ProfileTitle { get; set; }
        public bool? Profilevip { get; set; }
        public string WeightUomId { get; set; }
        public int WeightValue { get; set; }
        public string ProgramId { get; set; }
        public bool SoftMember { get; set; }
        public decimal TotalMarker { get; set; }
        public bool IsVip { get; set; }
        public decimal SignitureId { get; set; }
        public Byte[] SignitureImage { get; set; }
        public string SignitureImageUrl { get; set; }
    }
}
