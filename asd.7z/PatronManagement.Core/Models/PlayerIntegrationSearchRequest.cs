using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public class PlayerIntegrationSearchRequest
    {
        public PlayerIntegrationSearchCriteria criteria { get; set; }

        public PlayerSortByEnum sortBy { get; set; }

        public Pagination pager { get; set; }
    }

    public class PlayerIntegrationSearchCriteria
    {
        public string GivenName { get; set; }

        public string FamilyName { get; set; }

        public IList<GenderEnum> Genders { get; set; }

        public bool? InHouse { get; set; }

        public DateOfBirth DateOfBirth { get; set; }
    }

    public enum GenderEnum
    {
        CUSTOM_CODE = 0,

        NOT_SPECIFIED = 1,

        MALE = 2,

        FEMALE = 3
    }

    public class DateOfBirth
    {
        /// <summary>
        /// Gets or sets the year of player's birthday.
        /// </summary>
        public int? YearOfBirth { get; set; }

        /// <summary>
        /// Gets or sets the month of player's birthday.
        /// </summary>
        public int? MonthOfBirth { get; set; }

        /// <summary>
        /// Gets or sets the day of player's birthday.
        /// </summary>
        public int? DayOfBirth { get; set; }
    }
}