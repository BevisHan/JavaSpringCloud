﻿using System;
using System.Collections.Generic;
namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmImage {
        public decimal ImageId { get; set; }
        public bool? ImageActive { get; set; }
        public string ImageName { get; set; }
        public int? Version { get; set; }
    }
}
