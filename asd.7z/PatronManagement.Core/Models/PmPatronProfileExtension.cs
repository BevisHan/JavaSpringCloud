﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronProfileExtension
    {
        public decimal Id { get; set; }
        public bool? IsReceiveEmail { get; set; }
        public bool? IsReceivesms { get; set; }
        public decimal? TotalReInvestmentBudget { get; set; }
        public decimal? PatronProfileId { get; set; }
        public string WeChat { get; set; }
        public double? Adt { get; set; }
        public double? CustomerWinloss { get; set; }
        public decimal? MrketingHost { get; set; }
        public int? Version { get; set; }
    }
}
