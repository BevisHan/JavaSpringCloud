﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmJunketRep {
        public decimal JunketRepId { get; set; }
        public bool? JunketRepActive { get; set; }
        public string JunketRepName { get; set; }
        public int? Version { get; set; }
    }
}
