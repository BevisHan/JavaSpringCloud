﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmMarketingHost {
        public decimal Id { get; set; }
        public string PhoneNumber { get; set; }
        public int? Version { get; set; }
        public string MarketerName { get; set; }
    }
}
