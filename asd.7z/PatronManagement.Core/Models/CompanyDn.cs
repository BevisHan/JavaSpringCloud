﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class CompanyDn {
        public int Id { get; set; }
        public string Company { get; set; }
        public string Property { get; set; }
        public string CompanyName { get; set; }
        public string PropertyName { get; set; }
        public string DomainName { get; set; }
        public int? TenantId { get; set; }
        public int? Version { get; set; }
    }
}
