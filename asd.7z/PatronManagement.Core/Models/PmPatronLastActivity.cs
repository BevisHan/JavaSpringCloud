﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronLastActivity
    {
        public decimal PatronLastActivityId { get; set; }
        public string Activity { get; set; }
        public DateTime? ActivityDate { get; set; }
        public string ActivityShortDesc { get; set; }
        public string ActivityType { get; set; }
        public string PatronId { get; set; }
        public int? Version { get; set; }
    }
}
