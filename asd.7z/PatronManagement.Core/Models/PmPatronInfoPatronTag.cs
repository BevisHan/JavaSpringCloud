﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronInfoPatronTag
    {
        public decimal PatronInfo { get; set; }
        public decimal PatronTag { get; set; }
    }
}
