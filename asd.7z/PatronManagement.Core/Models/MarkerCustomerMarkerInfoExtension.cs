﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class MarkerCustomerMarkerInfoExtension {
        public string Id { get; set; }
        public string MarkerCustomerMarkerInfoId { get; set; }
        public string AttributeName { get; set; }
        public string Value { get; set; }
    }
}
