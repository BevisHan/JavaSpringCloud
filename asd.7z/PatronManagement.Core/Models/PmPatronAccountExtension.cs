﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmPatronAccountExtension {
        public decimal Id { get; set; }
        public double? AccountAvailability { get; set; }
        public double AccountBalance { get; set; }
        public string AccountType { get; set; }
        public int CompItemId { get; set; }
        public int CompLocId { get; set; }
        public double? ForeignAvailability { get; set; }
        public double? ForeignBalance { get; set; }
        public DateTime? ForeignExpiry { get; set; }
        public int ForeignId { get; set; }
        public double? ForeignRate { get; set; }
        public DateTime? UpdateTime { get; set; }
        public int? Version { get; set; }
        public decimal? PatronInfo { get; set; }
    }
}
