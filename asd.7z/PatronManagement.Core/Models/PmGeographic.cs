﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmGeographic {
        public decimal Id { get; set; }
        public string AnyAttribute { get; set; }
        public bool? GeographicActive { get; set; }
        public string GeographicId { get; set; }
        public string GeographicName { get; set; }
        public int? Version { get; set; }
    }
}
