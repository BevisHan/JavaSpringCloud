﻿namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmAddressLine {
        public decimal Line { get; set; }
        public string AddressLineValue { get; set; }
        public int? Version { get; set; }
        public decimal? PatronAddress { get; set; }
    }
}
