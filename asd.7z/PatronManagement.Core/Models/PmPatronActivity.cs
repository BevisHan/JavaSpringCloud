﻿using System;

namespace Augmentum.PatronManagement.Core.Models {
    public partial class PmPatronActivity {
        public decimal PatronActivityId { get; set; }
        public string Activity { get; set; }
        public string ActivityShortDesc { get; set; }
        public DateTime? ActivityTime { get; set; }
        public string ActivityType { get; set; }
        public int? Version { get; set; }
        public string PatronTripId { get; set; }
    }
}
