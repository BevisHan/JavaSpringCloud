﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronName
    {
        public decimal Id { get; set; }
        public string FamilyName { get; set; }
        public string MiddleName { get; set; }
        public string GivenName { get; set; }
        public int? Version { get; set; }
        public decimal? LanguageId { get; set; }
        public decimal? PatronProfileId { get; set; }
    }
}
