using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{

    public class RegisterPatronInfoRequest
    {
        public RegisterPatronInfoRequest()
        {
            registerPatronInfo = new RegisterPatronInfo();
        }

        public RegisterPatronInfo registerPatronInfo { get; set; }
    }

    public class RegisterPatronInfo
    {
        public RegisterPatronInfo()
        {
            registerPatronProfile = new RegisterPatronProfile();
            patronEmail = new List<patronEmail>();
            patronPhone = new List<patronPhone>();
            patronAddress = new List<patronAddress>();
            patronIdent = new List<patronIdent>();
            patronSigniture = new patronSigniture();
        }

        public string patronId { get; set; }
        public string patronPin { get; set; }
        public RegisterPatronProfile registerPatronProfile { get; set; }
        public List<patronEmail> patronEmail { get; set; }
        public List<patronPhone> patronPhone { get; set; }
        public List<patronAddress> patronAddress { get; set; }
        public List<patronIdent> patronIdent { get; set; }
        public patronSigniture patronSigniture { get; set; }
    }

    public class RegisterPatronProfile
    {
        public RegisterPatronProfile()
        {
            patronName = new List<RegisterPatronName>();
        }

        public string familyName { get; set; }
        public string middleName { get; set; }
        public string givenName { get; set; }
        public List<RegisterPatronName> patronName { get; set; }
        public string title { get; set; }
        public string gender { get; set; }
        public long birthday { get; set; }
        public string countryCodeId { get; set; }
    }

    public class RegisterPatronName
    {
        public string familyName { get; set; }
        public string middleName { get; set; }
        public string givenName { get; set; }
        public string languageName { get; set; }
    }
}
