using System;

namespace  Augmentum.PatronManagement.Core.Models
{
    public class GetHostRequest : PropertyAware
    {
        public string patronId { get; set; }

        public long currentTime
        {
            get
            {
                var interval = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
                return (long)interval;
            }
        }
    }

    public class GetHostResponse
    {
        public string hostName { get; set; }

        public string patronId { get; set; }

        public bool onDuty { get; set; }
    }
}