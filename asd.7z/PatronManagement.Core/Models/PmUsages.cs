﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmUsages
    {
        public decimal UsageId { get; set; }
        public bool? UsageActive { get; set; }
        public string UsageName { get; set; }
        public int? Version { get; set; }
    }
}
