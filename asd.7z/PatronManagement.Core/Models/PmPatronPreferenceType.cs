﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPatronPreferenceType
    {
        public decimal Id { get; set; }
        public string CompanyCode { get; set; }
        public string PreferenceTypeKeyword { get; set; }
        public string PreferenceTypeName { get; set; }
        public string PropertyCode { get; set; }
        public int? Version { get; set; }
    }
}
