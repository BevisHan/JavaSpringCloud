﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmProfileAttribute
    {
        public decimal Id { get; set; }
        public string AttributeId { get; set; }
        public string ProfileAttributeValue { get; set; }
        public int? Version { get; set; }
        public decimal? PatronProfile { get; set; }
    }
}
