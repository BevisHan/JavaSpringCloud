namespace Augmentum.PatronManagement.Core.Models
{
    public class PlayerIntegrationSearchByHostRequest
    {
        public PlayerIntegrationSearchByHostCriteria criteria { get; set; }

        public string sortBy { get; set; }

        public Pagination pager { get; set; }
    }

    public class PlayerIntegrationSearchByHostCriteria
    {
        public string hostName { get; set; }
    }
}
