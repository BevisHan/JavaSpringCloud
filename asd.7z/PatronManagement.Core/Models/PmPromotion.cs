﻿using System;
using System.Collections.Generic;

namespace Augmentum.PatronManagement.Core.Models
{
    public partial class PmPromotion
    {
        public decimal Id { get; set; }
        public decimal? Uid { get; set; }
        public string Couponid { get; set; }
        public string CouponType { get; set; }
        public string GiftNumber { get; set; }
        public string PatronId { get; set; }
        public string Property { get; set; }
        public int? Version { get; set; }
    }
}
