using Augmentum.PatronManagement.Core.Models;


namespace Augmentum.PatronManagement.Core.Services
{
    public interface IPatronService
    {
        PatronSearchResult GetPatronListByKeyword(PlayerIntegrationSearchByKeywordRequest playerIntegrationSearchByKeywordRequest);

    }
}
