using Augmentum.PatronManagement.Core.Models;
using Microsoft.Extensions.Logging;
using EntityFramework.DbContextScope.Interfaces;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using Augmentum.PatronManagement.Core.Db;

namespace Augmentum.PatronManagement.Core.Services
{
    public class PatronService : IPatronService
    {
        private readonly ILogger<PatronService> _logger;

        private readonly IReadDbFacade _readDbFacade;
        private readonly IDbContextScopeFactory _dbContextScopeFactory;

        public PatronService(
            ILogger<PatronService> logger,
            IReadDbFacade readDbFacade,
            IDbContextScopeFactory dbContextScopeFactory)
        {
            _logger = logger;
            _readDbFacade = readDbFacade;
            _dbContextScopeFactory = dbContextScopeFactory;
        }

        public PatronSearchResult GetPatronListByKeyword(PlayerIntegrationSearchByKeywordRequest playerIntegrationSearchByKeywordRequest)
        {
            PatronSearchResult searchResults = new PatronSearchResult();

            using (var dbScope = _dbContextScopeFactory.CreateWithTransaction(IsolationLevel.ReadCommitted))
            {
                IList<PatronInfoView> result = (from pi in _readDbFacade.PmPatronInfos.ToList()
                                                join pp in _readDbFacade.PmPatronProfiles.ToList()
                                                  on pi.Id equals pp.PatronInfo
                                                join lppe in _readDbFacade.PmPatronProfileExtensions.ToList()
                                                  on pp.Id equals lppe.PatronProfileId into nullppe
                                                from ppe in nullppe.DefaultIfEmpty()
                                                join lmh in _readDbFacade.PmMarketingHosts.ToList()
                                                  on ppe.MrketingHost equals lmh.Id into nullmh
                                                from mh in nullmh.DefaultIfEmpty()
                                                join lpn in _readDbFacade.PmPatronNames.ToList()
                                                  on new { Id = pp.Id, LanguageId = pp.LanguageId } equals new { Id = lpn.Id, LanguageId = lpn.LanguageId } into nullpn
                                                from pn in nullpn.DefaultIfEmpty()
                                                join lsi in _readDbFacade.PmPatronSignitureImages.ToList()
                                                  on pi.Id equals lsi.PatronInfo into nullsi
                                                from si in nullsi.DefaultIfEmpty(new PmPatronSignitureImage { PatronIdentSignitureId = 0 })
                                                select new PatronInfoView
                                                {
                                                    AnyAttribute = pi.AnyAttribute,
                                                    PatronId = pi.PatronId,
                                                    Adt = ppe.Adt,
                                                    CustomerWinloss = ppe.CustomerWinloss,
                                                    IsReceiveEmail = ppe.IsReceiveEmail,
                                                    IsReceivesms = ppe.IsReceivesms,
                                                    MarketerName = mh.MarketerName,
                                                    PhoneNumber = mh.PhoneNumber,
                                                    HostVersion = mh.Version,
                                                    PatronProfileId = pp.PatronInfo,
                                                    ProfileVersion = pp.Version,
                                                    WeChat = ppe.WeChat,
                                                    CtrStatus = pp.CtrStatus,
                                                    GenderType = pp.GenderType,
                                                    GeographicId = pp.GeographicId,
                                                    IsCreditCustomer = pp.IsCreditCustomer,
                                                    IsGamingCustomer = pp.IsGamingCustomer,
                                                    IsLocked = pp.IsLocked,
                                                    JunketId = pp.JunketId,
                                                    JunketRepId = pp.JunketRepId,
                                                    LanguageId = pp.LanguageId,
                                                    MaritalStatus = pp.MaritalStatus,
                                                    ProfileActive = pp.ProfileActive,
                                                    ProfileAge = pp.ProfileAge,
                                                    ProfileAnniversary = pp.ProfileAnniversary,
                                                    ProfileBirthday = pp.ProfileBirthday,
                                                    ProfileEye = pp.ProfileEye,
                                                    ProfileFirstName = pp.GivenName,
                                                    ProfileFullName = pp.ProfileFullName,
                                                    ProfileGeneration = pp.ProfileGeneration,
                                                    ProfileHair = pp.ProfileHair,
                                                    HeightUomId = pp.HeightUomId,
                                                    HeightValue = pp.HeightValue,
                                                    ProfileLastName = pp.FamilyName,
                                                    ProfileLastPlay = pp.ProfileLastPlay,
                                                    ProfileMaiden = pp.ProfileMaiden,
                                                    ProfileMiddleName = pp.MiddleName,
                                                    ProfilePreferred = pp.ProfilePreferred,
                                                    ProfileRank = pp.ProfileRank,
                                                    ProfileSkin = pp.ProfileSkin,
                                                    ProfileSuffix = pp.ProfileSuffix,
                                                    ProfileTitle = pp.ProfileTitle,
                                                    Profilevip = pp.Profilevip,
                                                    WeightUomId = pp.WeightUomId,
                                                    WeightValue = pp.WeightValue,
                                                    ProgramId = pp.ProgramId,
                                                    SoftMember = pp.SoftMember,
                                                    IsVip = (pp.ProfileRank == "Platinum" || pp.ProfileRank == "Black") ? true : false,
                                                    SignitureId = si.PatronIdentSignitureId,
                                                    SignitureImage = si.SignitureImage,
                                                    SignitureImageUrl = si.SignitureImageUrl
                                                }
                                              ).ToList();
                searchResults.patronInfo = searchResults.patronInfo.Concat(searchResults.ConvertToResponseModel(result)).ToList();
                searchResults.totalCount = result.Count();
            }
            return searchResults;
        }
    }
}
