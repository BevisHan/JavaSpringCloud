using Augmentum.PatronManagement.Core.Db;
using Augmentum.PatronManagement.Core.Models;

namespace Augmentum.PatronManagement.Core.Repositories
{
    public interface IPatronInfoViewRepository : IRepository<PatronInfoView>
    {
    }
}
