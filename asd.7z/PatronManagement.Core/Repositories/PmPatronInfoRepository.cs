using Augmentum.PatronManagement.Core.Db;
using Augmentum.PatronManagement.Core.Models;
using EntityFramework.DbContextScope.Interfaces;
using System.Linq;

namespace Augmentum.PatronManagement.Core.Repositories
{
    public class PmPatronInfoRepository : Repository<PmPatronInfo>, IPmPatronInfoRepository
    {

        public PmPatronInfoRepository(IAmbientDbContextLocator dbContextLocator) : base(dbContextLocator)
        {
        }

        public PmPatronInfo GetDomainPatronInfoByPatronId(string patronId)
        {
            return Set.FirstOrDefault(s => s.PatronId.Equals(patronId));
        }

    }
}
