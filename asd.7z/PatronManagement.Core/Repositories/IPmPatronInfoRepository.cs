using Augmentum.PatronManagement.Core.Db;
using Augmentum.PatronManagement.Core.Models;

namespace Augmentum.PatronManagement.Core.Repositories
{
    public interface IPmPatronInfoRepository : IRepository<PmPatronInfo>
    {
        PmPatronInfo GetDomainPatronInfoByPatronId(string patronId);
    }
}
