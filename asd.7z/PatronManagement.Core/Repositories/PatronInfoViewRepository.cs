using Augmentum.PatronManagement.Core.Db;
using Augmentum.PatronManagement.Core.Models;
using EntityFramework.DbContextScope.Interfaces;


namespace Augmentum.PatronManagement.Core.Repositories
{
    public class PatronInfoViewRepository : Repository<PatronInfoView>, IPatronInfoViewRepository
    {

        public PatronInfoViewRepository(IAmbientDbContextLocator dbContextLocator) : base(dbContextLocator)
        {
        }

    }
}
