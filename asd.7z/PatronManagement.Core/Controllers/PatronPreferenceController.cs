using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using Augmentum.PatronManagement.Core.Services;

namespace Augmentum.PatronManagement.Core.Controllers
{
    [Route("/api/patronPreference/")]
    public class PatronPreferenceController : Controller
    {
        private readonly ILogger<PatronPreferenceController> _logger;

        public PatronPreferenceController(ILogger<PatronPreferenceController> logger)
        {
            _logger = logger;
        }

        [HttpPost("{patronId}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetPreferenceByPatronId(string patronId)
        {
            throw new NotImplementedException();
        }

    }

}
