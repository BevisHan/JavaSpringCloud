﻿using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;

namespace Augmentum.PatronManagement.Core.Controllers
{
    [Route("/api/patronaccounts/")]
    public class PatronAccountController : Controller
    {
        private readonly ILogger<PatronAccountController> _logger;

        public PatronAccountController(ILogger<PatronAccountController> logger)
        {
            _logger = logger;
        }

        [HttpPost("patronaccount/{patronId}/remainreinvestmentbudget/increase/{delta}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult IncreaseRemainReInvestmentBudgetBalance(string patronId, double delta)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patronaccount/{patronId}/point/24hours")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetPointBalanceWithBlanceIn24Hours(string patronId)
        {
            throw new NotImplementedException();
        }

        [HttpPost("{patronId}/pointandcomp")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetPatronPointCompAccounts(string patronId)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patronaccount/{patronId}/pointandaccounts")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetPatronPointAndRemainReInvestmentBudgetAndPoint24hours(string patronId)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patronaccount/{patronId}/reinvestment/deduct/{delta}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult DeductReInvestmentBalance(string patronId, string delta)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patronaccount/{patronId}/accounts")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetPatronAccounts(string patronId)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patronaccount/{patronId}/slotcredit/increase/{delta}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult IncreaseSlotCreditBalance(string patronId, string delta)
        {
            throw new NotImplementedException();
        }
        
        [HttpPost("patronaccount/{patronId}/point/deduct/{delta}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult DeductPointBalance(string patronId, string delta)
        {
            throw new NotImplementedException();
        }
    }
}
