﻿using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using Augmentum.PatronManagement.Core.Models;

namespace Augmentum.PatronManagement.Core.Controllers
{
    [Route("/api/trips/")]
    public class TripController : Controller
    {
        private readonly ILogger<TripController> _logger;

        public TripController(ILogger<TripController> logger)
        {
            _logger = logger;
        }

        [HttpPost("create")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Create trip succuessfully.")]
        public ActionResult CreateTrip([FromBody] IntegrationCreateTripRequest createTripRequest)
        {
            throw new NotImplementedException();
        }

        [HttpPost("close/{patronTripId}")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Create trip succuessfully.")]
        public ActionResult CloseTrip(string patronTripId)
        {
            throw new NotImplementedException();
        }
    }
}
