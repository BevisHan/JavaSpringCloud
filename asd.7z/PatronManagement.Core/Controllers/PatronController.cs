﻿using System;
using System.Net;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using Augmentum.PatronManagement.Core.Models;
using Augmentum.PatronManagement.Core.Services;

namespace Augmentum.PatronManagement.Core.Controllers
{
    [Route("/api/patroninfoes/")]
    public class PatronController : Controller
    {
        private readonly ILogger<PatronController> _logger;

        private readonly IPatronService _patronService;
        public PatronController(ILogger<PatronController> logger,
        IPatronService patronService)
        {
            _logger = logger;

            _patronService = patronService;
        }

        [HttpGet("patroninfo/authentication/{patronId}/{patronPIN}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult AuthenticatePatronByPatronIdAndPIN(string patronId, string patronPIN)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patroninfo/register")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult Register([FromBody] RegisterPatronInfoRequest registerPatronInfoRequest)
        {
            throw new NotImplementedException();
        }
                
        [HttpPost("patroninfo/partialRegister")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult PartialRegister([FromBody] PartialRegisterRequest partialRegisterRequest)
        {
            throw new NotImplementedException();
        }
        
        [HttpPost("patroninfo/resetPatronPinByPhoneNumber")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult ChangePinByPhone([FromQuery] string phoneNumber, string newPin)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patroninfo/{patronId}/emails")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult UpdateEmails(string patronId, [FromBody] IList<patronEmail> patronEmails)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patroninfo/{patronId}/phones")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult UpdatePhones(string patronId, [FromBody] IList<patronPhone> patronPhones)
        {
           throw new NotImplementedException();
        }

        [HttpPost("patroninfo/{patronId}/subscribe")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult UpdateSubscription(string patronId, [FromBody] PatronProfileExtension patronProfileExtension)
        {
           throw new NotImplementedException();
        }

        [HttpPost("patroninfo/getMyAllHosts")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetAllHostByPatronId([FromBody] GetHostRequest getHostRequest)
        {
            throw new NotImplementedException();
        }

        [HttpPost("reset")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult ResetPMDB()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get Patron Info By Id
        /// </summary>
        /// <param name="patronId"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        [HttpGet("patroninfo/{patronId}")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Get patron info by id succuessfully.")]
        public ActionResult GetPatronInfoById(string patronId, [FromQuery] string property)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patroninfo/{patronId}/preferences")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Update Preferences By Patron Id Succuessfully.")]
        public ActionResult UpdatePreferences(string patronId, [FromBody] PlayerPreference[] preferences)
        {
           throw new NotImplementedException();
        }

        /// <summary>
        /// Get Patron Info By Card Id
        /// </summary>
        /// <param name="cardId"></param>
        /// <returns></returns>
        [HttpGet("patroninfo/patroncard/{cardId}")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Get patron info by Patron Card Id succuessfully.")]
        public ActionResult GetPatronInfoByPatronCardId(string cardId)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Search Patron List
        /// </summary>
        /// <param name="playerIntegrationSearchRequest"></param>
        /// <returns></returns>
        [HttpPost("search")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Get patron list succuessfully.")]
        public ActionResult GetPatronList([FromBody] PlayerIntegrationSearchRequest playerIntegrationSearchRequest)
        {
           throw new NotImplementedException();
        }
    
        /// <summary>
        /// Search Patron List By Keyword
        /// </summary>
        /// <param name="playerIntegrationSearchByKeywordRequest"></param>
        /// <returns></returns>
        [HttpPost("search/keyword")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Get patron list by keyword succuessfully.")]
        public ActionResult GetPatronListByKeyword([FromBody] PlayerIntegrationSearchByKeywordRequest playerIntegrationSearchByKeywordRequest)
        {
            if (playerIntegrationSearchByKeywordRequest != null)
            {
                return Json(_patronService.GetPatronListByKeyword(playerIntegrationSearchByKeywordRequest));
            }
            else
            {
                throw new ArgumentException("playerIntegrationSearchByKeywordRequest is null.");
            }
        }

        /// <summary>
        /// Search Patron List By Host
        /// </summary>
        /// <returns></returns>
        [HttpPost("search/host")]
        [SwaggerResponse((int)HttpStatusCode.OK, "Get patron list by host succuessfully.")]
        public ActionResult GetPatronListByHost([FromBody] PlayerIntegrationSearchByHostRequest playerIntegrationSearchByHostRequest)
        {
            throw new NotImplementedException();
        }

        [HttpPost("patroninfo/stopcode/{patronId}")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult StopCode(string patronId)
        {
           throw new NotImplementedException();
        }

    }

}