using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;

namespace Augmentum.PatronManagement.Core.Controllers
{
    [Route("/api/junkets")]
    public class JunketController : Controller
    {
        private readonly ILogger<JunketController> _logger;

        public JunketController(ILogger<JunketController> logger)
        {
            _logger = logger;
        }

        [HttpPost("junkets")]
        [SwaggerResponse((int)HttpStatusCode.OK)]
        public ActionResult GetActiveJunkets()
        {
            throw new NotImplementedException();
        }
    }
}
